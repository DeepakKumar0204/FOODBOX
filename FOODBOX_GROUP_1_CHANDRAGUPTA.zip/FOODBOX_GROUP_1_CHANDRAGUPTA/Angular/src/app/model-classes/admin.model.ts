export class Admin{
    adminId!:number;
    name!:string;
    email!:string;
    employeeId!:string;
    password!:string;
    
}